<table style="border-collapse: collapse; border: none;">
  <tr style="border-collapse: collapse; border: none;">
    <td style="border-collapse: collapse; border: none;">
      <a href="http://www.openairinterface.org/">
         <img src="./images/oai_final_logo.png" alt="" border=3 height=50 width=150>
         </img>
      </a>
    </td>
    <td style="border-collapse: collapse; border: none; vertical-align: center;">
      <b><font size = "5">OpenAirInterface Core Network Docker Deployment Home Page</font></b>
    </td>
  </tr>
</table>

**Table of Contents**

1.  [Pre-requisites](./DEPLOY_PRE_REQUESITES.md)
2.  [Building the Docker Images](./BUILD_IMAGES.md)
3.  [Configuring the Containers](./CONFIGURE_CONTAINERS.md)
4.  [Running the Network Functions](./RUN_CNF.md)
5.  [Generating Traffic to a connected UE](./GENERATE_TRAFFIC.md)
